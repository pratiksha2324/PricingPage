import React from "react";
import Navbar from "./components/Navbar";
import PlanSubscription from "./components/PlanSubscription";
import PricingPlans from "./components/PricingPlans";

export default function App() {
  return (
    <div className="min-h-screen bg-gray-100">
      <Navbar />
      <PlanSubscription />
      <PricingPlans />
    </div>
  );
}

