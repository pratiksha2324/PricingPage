export default function PlanSubscription() {
  return (
    <div className="max-w-4xl mx-auto bg-white shadow-md p-6 mt-6 rounded-lg">
      {/* Main Heading - Larger Text */}
      <h2 className="text-3xl font-bold mb-2 text-left">Plan Subscription</h2>

      {/* Thin Line Divider with More Spacing Below */}
      <hr className="border-t border-gray-300 mb-6" />

      {/* Grid Content */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-sm">
        {/* Left Side */}
        <div className="space-y-4 text-left">
          <p><strong>Current Plan:</strong> Teams</p>
          <p><strong>Type:</strong> Monthly</p>
          <p><strong>Status:</strong> Trial</p>
        </div>

        {/* Right Side */}
        <div className="space-y-4 text-left">
          <p><strong>Upcoming Invoice:</strong> 3/31/2026, 7:26 PM</p>
          <p><strong>Invoice Amount:</strong> $15/month</p>
          <p><strong>Seats:</strong> 1</p>
        </div>
      </div>
    </div>
  );
}
