import { useState } from "react";

export default function PricingPlans() {
  const [billingCycle, setBillingCycle] = useState("monthly");
  const [selectedPlan, setSelectedPlan] = useState("Teams");

  const plans = [
    {
      name: "Basic",
      monthlyPrice: 10,
      yearlyPrice: 96,
      features: ["Essential analytics", "Standard reporting", "Email support"],
    },
    {
      name: "Teams",
      monthlyPrice: 15,
      yearlyPrice: 144,
      features: ["Essential analytics", "Standard reporting", "Email support"],
      highlight: true,
    },
    {
      name: "Enterprise",
      monthlyPrice: 20,
      yearlyPrice: 192,
      features: ["Essential analytics", "Standard reporting", "Email support"],
    },
  ];

  const CheckIcon = ({ className }) => (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      width="16"
      height="16"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <polyline points="20 6 9 17 4 12"></polyline>
    </svg>
  );

  return (
    <div className="max-w-4xl mx-auto mt-6 bg-white shadow-md p-6 rounded-lg">
      {/* Title and Toggle Row */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-4">
        <h2 className="text-2xl font-bold text-left mb-2 md:mb-0">Plans & Pricing</h2>
        <div className="inline-flex rounded-md overflow-hidden border border-gray-300">
          <button
            className={`px-4 py-2 text-sm font-medium focus:outline-none transition ${
              billingCycle === "monthly"
                ? "bg-black text-white"
                : "bg-white text-gray-700 hover:bg-gray-100"
            }`}
            onClick={() => setBillingCycle("monthly")}
          >
            Monthly
          </button>
          <button
            className={`px-4 py-2 text-sm font-medium focus:outline-none transition ${
              billingCycle === "yearly"
                ? "bg-black text-white"
                : "bg-white text-gray-700 hover:bg-gray-100"
            }`}
            onClick={() => setBillingCycle("yearly")}
          >
            Yearly
          </button>
        </div>
      </div>

      {/* Pricing Cards */}
      <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-6 mt-6">
        {plans.map((plan) => {
          const isSelected = plan.name === selectedPlan;
          return (
            <div
              key={plan.name}
              className={`p-6 border rounded-lg text-center cursor-pointer transition ${
                isSelected ? "bg-blue-900 text-white" : "bg-white"
              }`}
              onClick={() => setSelectedPlan(plan.name)}
            >
              <h3 className="text-lg font-bold">{plan.name}</h3>
              <p className={`text-sm ${isSelected ? "text-gray-200" : "text-gray-600"}`}>
                {plan.description}
              </p>

              <p className={`text-sm mt-2 ${isSelected ? "text-gray-200" : "text-gray-600"}`}>
                For all individuals and starters who want to start domaining
              </p>

              <hr className={`my-3 ${isSelected ? "border-white" : "border-black"}`} />

              <div className="flex flex-col items-center">
                <p className="text-2xl font-bold mt-2">
                  ${billingCycle === "monthly" ? plan.monthlyPrice : plan.yearlyPrice}
                  <span className="text-sm">/{billingCycle === "monthly" ? "month" : "year"}</span>
                </p>

                <button
                  className={`mt-3 px-4 py-2 rounded w-auto transition ${
                    isSelected ? "bg-white text-blue-900" : "bg-black text-white"
                  }`}
                >
                  Buy now
                </button>
              </div>

              <ul className="mt-4 text-sm space-y-3 text-left pl-4">
                {plan.features.map((feature, index) => (
                  <li key={index} className="flex items-center gap-3">
                    <CheckIcon
                      className={`flex-shrink-0 ${
                        isSelected ? "text-white" : "text-green-500"
                      }`}
                    />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
            </div>
          );
        })}
      </div>
    </div>
  );
}
