export default function Navbar() {
    return (
      
        
        <h1 className="text-lg font-semibold">Pricing Page</h1>
     
    );
  }
  